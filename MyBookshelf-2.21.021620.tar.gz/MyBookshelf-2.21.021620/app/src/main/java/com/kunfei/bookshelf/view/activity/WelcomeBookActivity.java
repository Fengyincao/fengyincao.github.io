package com.kunfei.bookshelf.view.activity;

public class WelcomeBookActivity extends WelcomeActivity {

}
