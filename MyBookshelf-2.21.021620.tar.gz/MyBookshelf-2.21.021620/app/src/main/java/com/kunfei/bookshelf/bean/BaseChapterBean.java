package com.kunfei.bookshelf.bean;

public interface BaseChapterBean {

    String getTag();

    String getDurChapterUrl();

    int getDurChapterIndex();

    String getNoteUrl();

    String getDurChapterName();
}
