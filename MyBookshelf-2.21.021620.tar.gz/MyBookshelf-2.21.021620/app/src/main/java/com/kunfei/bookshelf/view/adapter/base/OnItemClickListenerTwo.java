package com.kunfei.bookshelf.view.adapter.base;

import android.view.View;

public interface OnItemClickListenerTwo {
    void onClick(View view, int index);

    void onLongClick(View view, int index);
}
