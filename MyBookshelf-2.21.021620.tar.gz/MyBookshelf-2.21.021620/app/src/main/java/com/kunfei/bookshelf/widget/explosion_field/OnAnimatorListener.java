package com.kunfei.bookshelf.widget.explosion_field;

import android.animation.Animator;
import android.view.View;

public interface OnAnimatorListener {
    void onAnimationEnd(Animator animator, View view);
}
