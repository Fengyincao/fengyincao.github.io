package com.kunfei.bookshelf.widget.recycler.refresh;

public interface OnLoadMoreListener {

    public void startLoadMore();

    public void loadMoreErrorTryAgain();
}
